Getting Started: 


Problem Statement: 
 - Developed Quiz Application using HTML5, CSS3, Javascript and Jquery 
 - CSS framework used Bootstrap 5



Completed: 

- Basic UI of Quiz application including responsive.
- Progress bar to show time left.
- Show next question after every 10 seconds.
- If wrong answer is selected it will highlight correct answer.
- Skip question to move to next question without answering.
- Exit quiz to go back to main form. 
