 const quizData = {
        js_basic: [
          {
            "id": "q1",
            "question": "What is the correct syntax for referring to an external script called 'script.js'?",
            "options": [
              "A. <script name='script.js'>",
              "B. <script href='script.js'>",
              "C. <script src='script.js'>",
              "D. <script file='script.js'>"
            ],
            "correctAnswer": "C. <script src='script.js'>",
            "timeLimit": 10
          },
          {
            "id": "q2",
            "question": "Which company developed JavaScript?",
            "options": [
              "A. Microsoft",
              "B. Netscape",
              "C. Google",
              "D. Mozilla"
            ],
            "correctAnswer": "B. Netscape",
            "timeLimit": 10
          },
          {
            "id": "q3",
            "question": "Which keyword is used to declare a variable in JavaScript?",
            "options": [
              "A. var",
              "B. int",
              "C. let",
              "D. both A and C"
            ],
            "correctAnswer": "D. both A and C",
            "timeLimit": 10
          },
          {
            "id": "q4",
            "question": "Which of the following is a JavaScript data type?",
            "options": [
              "A. Number",
              "B. Float",
              "C. Character",
              "D. Token"
            ],
            "correctAnswer": "A. Number",
            "timeLimit": 10
          },
          {
            "id": "q5",
            "question": "How do you write 'Hello World' in an alert box?",
            "options": [
              "A. msgBox('Hello World');",
              "B. alert('Hello World');",
              "C. alertBox('Hello World');",
              "D. msg('Hello World');"
            ],
            "correctAnswer": "B. alert('Hello World');",
            "timeLimit": 10
          },
          {
            "id": "q6",
            "question": "Which method converts JSON data to a JavaScript object?",
            "options": [
              "A. JSON.toObject()",
              "B. JSON.parse()",
              "C. JSON.stringify()",
              "D. JSON.decode()"
            ],
            "correctAnswer": "B. JSON.parse()",
            "timeLimit": 10
          },
          {
            "id": "q7",
            "question": "What is the output of `typeof null` in JavaScript?",
            "options": [
              "A. null",
              "B. object",
              "C. undefined",
              "D. boolean"
            ],
            "correctAnswer": "B. object",
            "timeLimit": 10
          },
          {
            "id": "q8",
            "question": "Which symbol is used for single-line comments in JavaScript?",
            "options": [
              "A. <!-- -->",
              "B. ##",
              "C. //",
              "D. **"
            ],
            "correctAnswer": "C. //",
            "timeLimit": 10
          },
          {
            "id": "q9",
            "question": "Which function is used to output content to the browser console?",
            "options": [
              "A. print()",
              "B. console.write()",
              "C. log.console()",
              "D. console.log()"
            ],
            "correctAnswer": "D. console.log()",
            "timeLimit": 10
          },
          {
            "id": "q10",
            "question": "Which keyword is used to define a constant in JavaScript?",
            "options": [
              "A. const",
              "B. constant",
              "C. final",
              "D. let"
            ],
            "correctAnswer": "A. const",
            "timeLimit": 10
          }
        ],
        react_advance: [
          {
            "id": "r1",
            "question": "What is the purpose of useEffect in React?",
            "options": [
              "A. To manage state",
              "B. To perform side effects",
              "C. To create components",
              "D. To define props"
            ],
            "correctAnswer": "B. To perform side effects",
            "timeLimit": 10
          },
          {
            "id": "r2",
            "question": "Which hook is used to manage state in a functional component?",
            "options": [
              "A. useState",
              "B. useEffect",
              "C. useReducer",
              "D. useContext"
            ],
            "correctAnswer": "A. useState",
            "timeLimit": 10
          },
          {
            "id": "r3",
            "question": "What is JSX?",
            "options": [
              "A. JavaScript XML",
              "B. JSON Syntax Extension",
              "C. Java Source Extension",
              "D. A templating language"
            ],
            "correctAnswer": "A. JavaScript XML",
            "timeLimit": 10
          },
          {
            "id": "r4",
            "question": "Which method is used to pass data from parent to child component?",
            "options": [
              "A. state",
              "B. props",
              "C. setState",
              "D. context"
            ],
            "correctAnswer": "B. props",
            "timeLimit": 10
          },
          {
            "id": "r5",
            "question": "What does useMemo do in React?",
            "options": [
              "A. It memoizes values to avoid recalculation",
              "B. It memoizes components",
              "C. It fetches memo notes",
              "D. It caches API data"
            ],
            "correctAnswer": "A. It memoizes values to avoid recalculation",
            "timeLimit": 10
          },
          {
            "id": "r6",
            "question": "Which hook is preferred for complex state logic?",
            "options": [
              "A. useEffect",
              "B. useState",
              "C. useReducer",
              "D. useRef"
            ],
            "correctAnswer": "C. useReducer",
            "timeLimit": 10
          },
          {
            "id": "r7",
            "question": "What does React.StrictMode do?",
            "options": [
              "A. Prevents rendering",
              "B. Adds strict linting",
              "C. Highlights potential problems in an app",
              "D. Enables legacy features"
            ],
            "correctAnswer": "C. Highlights potential problems in an app",
            "timeLimit": 10
          },
          {
            "id": "r8",
            "question": "Which of the following is true about React keys?",
            "options": [
              "A. Keys should be random on each render",
              "B. Keys help React identify which items have changed",
              "C. Keys are required for styling",
              "D. Keys can only be numbers"
            ],
            "correctAnswer": "B. Keys help React identify which items have changed",
            "timeLimit": 10
          },
          {
            "id": "r9",
            "question": "How can you optimize performance in React apps?",
            "options": [
              "A. Avoid using keys",
              "B. Use useEffect everywhere",
              "C. Use memoization techniques like useMemo and React.memo",
              "D. Render components as often as possible"
            ],
            "correctAnswer": "C. Use memoization techniques like useMemo and React.memo",
            "timeLimit": 10
          },
          {
            "id": "r10",
            "question": "Which hook allows accessing DOM elements directly?",
            "options": [
              "A. useEffect",
              "B. useRef",
              "C. useState",
              "D. useContext"
            ],
            "correctAnswer": "B. useRef",
            "timeLimit": 10
          }
        ]
      };
      

    $(document).ready(function(){

      const questionB = document.getElementById("question-block");
      const optionB = document.getElementById("option-block");
      const resultB = document.getElementById("result-block");
      const nextBtn = document.getElementById("nextBtn");
      const skipBtn = document.getElementById("skipBtn");
      const progressBar = document.getElementById("progressBar");
      const progressBlock = document.getElementById("progressBlock");
      const exitQuiz = document.getElementById("exitQuiz");

      let newQuiz = [];
      let cIndex = 0;
      let quizScore = 0;
      let quizTimer;
      let quizTimeElapsed = 0;
      const quizQuestionTime = 10;
      let quizAnswered = false;

      $(".quiz-form").hide();

      // To hide main form on click of start quiz button
      $('.btn-start').on('click', function(){
        const category = $('input[name="topic"]:checked').val();
        if(category != null){
          $(".quiz-form").show();
          if (quizData[category]) {
            newQuiz = quizData[category];
            cIndex = 0;
            quizScore = 0;
            resultB.textContent = "";
            loadQuizQuestion();
            $('.main-form').hide();
          }
        }else{
          $(this).attr('disabled','disabled');
        }
        
      });

      $('input[name="topic"]').on('change', function(){
        $('.btn-start').removeAttr('disabled');
      })

      
      // Refreshing page on click of Exit quiz button
      $('.btn-exit').on('click', function(){
        window.location.reload(true);
      })

      
      // Function to Load quiz question
      function loadQuizQuestion() {
        clearInterval(quizTimer);
        quizTimeElapsed = 0;
        progressBarUpdate();
        quizAnswered = false;

        const current = newQuiz[cIndex];
        questionB.textContent = current.question;
        optionB.innerHTML = "";

        current.options.forEach(option => {
          const answerOption = document.createElement("div");
          answerOption.textContent = option;
          answerOption.classList.add("answer-option");
          const checkmark=document.createElement("div");
          checkmark.classList.add("checkmark");
          answerOption.appendChild(checkmark);
          answerOption.onclick = () => {
            answerOption.classList.add("checked");
            if (quizAnswered) return;
            quizAnswered = true;
            clearInterval(quizTimer);

            const allOptions = document.querySelectorAll(".answer-option");
            allOptions.forEach(b => b.disabled = true);
            
            if (option === current.correctAnswer) {
              answerOption.classList.add("correct"); // Added class for correct answer
              quizScore++;
            } else {
               answerOption.classList.add("incorrect"); // Added class for incorrect answer
              allOptions.forEach(b => {
                if (b.textContent === current.correctAnswer) {
                  b.classList.add("correct", "checked"); // Added class for correct answer
                }
              });
            }

            setTimeout(() => nextQuestion(), 10000); // Move to next after 10 sec
          };
          optionB.appendChild(answerOption);
        });

        quizTimer = setInterval(() => {
          quizTimeElapsed++;
          progressBarUpdate();
          if (quizTimeElapsed >= quizQuestionTime) {
            clearInterval(quizTimer);
            if (!quizAnswered) {
              quizAnswered = true;
              highlightCorrect();
              setTimeout(() => nextQuestion(), 10000);
            }
          }
        }, 9500);

        nextBtn.style.display = "inline-block";
        skipBtn.style.display = "inline-block";
        exitQuiz.style.display = "inline-block";
      }

      // Function to update progressbar
      function progressBarUpdate() {
        const percent = ((quizQuestionTime - quizTimeElapsed) / quizQuestionTime) * 100;
        progressBar.style.width = percent + "%";
      }

      nextBtn.onclick = () => {
        nextQuestion();
      };

      skipBtn.onclick = () => {
        nextQuestion();
      };

      // Function to show next question
      function nextQuestion() {
        clearInterval(quizTimer);
        cIndex++;
        if (cIndex < newQuiz.length) {
          loadQuizQuestion();
        } else {
          showResult();
        }
      }

      // Function to highlight correct answer
      function highlightCorrect() {
        const allOptions = document.querySelectorAll(".answer-option");
        allOptions.forEach(b => {
          b.disabled = true;
          if (b.textContent === newQuiz[cIndex].answer) {
            b.classList.add("correct", "checked"); // Add class to correct answer
            
          }
        });
      }

      // Function to show result
      function showResult() {
        questionB.textContent = "";
        optionB.innerHTML = "";
        progressBar.style.width = "0%";
        nextBtn.style.display = "none";
        skipBtn.style.display = "none";
        exitQuiz.style.display = "none";
        progressBlock.style.display = "none";
        let totalScore = quizScore * 100 / newQuiz.length;
        console.log(totalScore);
        if(totalScore > 80){
          resultB.innerHTML = `
          <div class="result-block">
            <img class="mb-40" src="images/sucess-emoji.svg" alt="Sucess" />
            <h4>Congratulation</h4>
            <p class="mb-40">You successfully completed the Quiz and holds</p>
            <p class="score-title">Your Score</p>
            <p class="score-value">${totalScore}%</p>
            <p class="score-message">Great job!</p>
          </div>
          `;
        }
        else if (totalScore <= 80 && totalScore >= 60 ){
          resultB.innerHTML = `
            <div class="result-block">
              <img class="mb-40" src="images/sucess-emoji.svg" alt="Sucess" />
              <h4>Congratulation</h4>
              <p class="mb-40">You successfully completed the Quiz and holds</p>
              <p class="score-title">Your Score</p>
              <p class="score-value">${totalScore}%</p>
              <p class="score-message">Well done!</p>
            </div>
            `;
        }
        else {
          resultB.innerHTML = `
          <div class="result-block">
              <img class="mb-40" src="images/sad-emoji.svg" alt="Sad" />
              <p class="mb-40">You successfully completed the Quiz but you need to</p>
              <h4>Keep practicing!</h4>
              <p class="score-title">Your Score</p>
              <p class="score-value failed">${totalScore}%</p>
          </div>
         `;
        }
        
      }

    })